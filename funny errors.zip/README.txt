Thanks for reading this!

How to run funny_errors:
1. extract the two batch files
2. open it_WILL_work_100_percent
3. look at your poor computer aww